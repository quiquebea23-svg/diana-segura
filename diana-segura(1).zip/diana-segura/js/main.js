// =========================================
// DIANA SEGURA · JS
// =========================================

// NAV: scroll state + dark hero
const nav = document.getElementById('nav');

function updateNav() {
  if (window.scrollY > 40) {
    nav.classList.add('scrolled');
    nav.classList.remove('hero-dark');
  } else {
    nav.classList.remove('scrolled');
    nav.classList.add('hero-dark');
  }
}

updateNav();
window.addEventListener('scroll', updateNav, { passive: true });

// BURGER MENU
const burger = document.getElementById('burger');
const navLinks = document.getElementById('navLinks');

burger.addEventListener('click', () => {
  burger.classList.toggle('open');
  navLinks.classList.toggle('open');
  document.body.style.overflow = navLinks.classList.contains('open') ? 'hidden' : '';
});

// Close menu on link click
navLinks.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    burger.classList.remove('open');
    navLinks.classList.remove('open');
    document.body.style.overflow = '';
  });
});

// Close menu on outside click
document.addEventListener('click', (e) => {
  if (navLinks.classList.contains('open') && !navLinks.contains(e.target) && !burger.contains(e.target)) {
    burger.classList.remove('open');
    navLinks.classList.remove('open');
    document.body.style.overflow = '';
  }
});

// REVEAL ON SCROLL
const reveals = document.querySelectorAll('[data-reveal]');

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const delay = el.dataset.delay || 0;
      setTimeout(() => {
        el.classList.add('visible');
      }, delay * 1000);
      revealObserver.unobserve(el);
    }
  });
}, { threshold: 0.12 });

// Add reveal class to major sections
document.querySelectorAll('.service-card, .review-card, .about-content, .about-visual, .contact-form, .contact-text').forEach((el, i) => {
  el.classList.add('reveal');
  el.dataset.delay = (i % 3) * 0.1;
  revealObserver.observe(el);
});

// SMOOTH SCROLL with offset for nav
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', (e) => {
    const target = document.querySelector(anchor.getAttribute('href'));
    if (!target) return;
    e.preventDefault();
    const offset = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--nav-h')) || 72;
    const top = target.getBoundingClientRect().top + window.scrollY - offset;
    window.scrollTo({ top, behavior: 'smooth' });
  });
});

// FORM SUBMIT
function handleSubmit(e) {
  e.preventDefault();
  const btn = document.getElementById('submitBtn');
  const btnText = document.getElementById('btnText');
  const success = document.getElementById('formSuccess');

  btn.disabled = true;
  btnText.textContent = 'Enviando...';

  // Simulate send — replace with real endpoint (Formspree, Netlify Forms, etc.)
  setTimeout(() => {
    btn.style.display = 'none';
    success.style.display = 'block';
    document.getElementById('contactForm').reset();
  }, 1200);
}

// HERO DARK on load (before scroll)
nav.classList.add('hero-dark');
