# Diana Segura · Fotografía

Web profesional para Diana Segura, fotógrafa en Reus, Cataluña.

## Estructura

```
diana-segura/
├── index.html       # Página principal
├── css/
│   └── style.css    # Estilos (responsive, desktop + mobile)
├── js/
│   └── main.js      # Interacciones, nav, animaciones, formulario
├── images/          # Pon aquí tus fotos
├── vercel.json      # Config de Vercel
└── README.md
```

## Desplegar en Vercel + GitHub

### Paso 1 — Subir a GitHub
```bash
git init
git add .
git commit -m "primera versión"
git remote add origin https://github.com/TU_USUARIO/diana-segura.git
git push -u origin main
```

### Paso 2 — Conectar con Vercel
1. Ve a [vercel.com](https://vercel.com) e inicia sesión con GitHub
2. "Add New Project" → selecciona el repositorio `diana-segura`
3. Framework: **Other** (static site)
4. Deploy → ¡listo en 30 segundos!

Vercel te dará una URL tipo `diana-segura.vercel.app`.
Para usar `dianasegura.com`, añádelo en Settings → Domains.

## Personalizar

### Foto de Diana
Añade tu foto en `images/diana.jpg` y en `index.html` reemplaza:
```html
<div class="about-photo-placeholder">...</div>
```
por:
```html
<img src="images/diana.jpg" alt="Diana Segura, fotógrafa" style="width:100%;height:100%;object-fit:cover;border-radius:200px 200px 20px 20px;" />
```

### Formulario de contacto real
En `js/main.js` función `handleSubmit`, reemplaza el `setTimeout` por:
```js
// Opción A — Formspree (gratis)
const res = await fetch('https://formspree.io/f/TU_ID', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(Object.fromEntries(new FormData(e.target)))
});

// Opción B — Netlify Forms: añade netlify al <form>
```

### Colores
En `css/style.css`, sección `:root`, cambia los valores de `--pink-*` y `--nude-*` a tu gusto.

## Fuentes usadas
- **Cormorant Garamond** — títulos elegantes (Google Fonts)
- **Jost** — cuerpo de texto moderno (Google Fonts)
